const os = require('os');
const path = require('path');

console.log(os.hostname());//Gives System Name
console.log(path.join(__dirname,'index.html')); //Create a Path
