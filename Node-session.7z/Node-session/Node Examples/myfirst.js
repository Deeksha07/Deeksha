var http = require('http');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
     console.log('Hello Dear!');
    res.end('Hello Dear!');
}).listen(8082);